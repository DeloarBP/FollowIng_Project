<?php

namespace App\Events;

use App\Models\Agent;
use App\Models\Indication;
use App\Models\Software;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class IndicationCreated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    protected  $indication = null;
    /**
     * constructor.
     *
     * @param Indication $indication
     */
    public function __construct(Indication $indication)
    {
        $this->indication = $indication;
    }

    /**
     * @return Indication|null
     */
    public function getIndication()
    {
        return $this->indication;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
