<?php

namespace App\Events;

use App\Models\Agent;
use App\Models\Software;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class SoftwareInstalled
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    protected  $software = null;

    /**
     * SoftwareInstalled constructor.
     *
     * @param Software $software
     */
    public function __construct(Software $software)
    {
        $this->software = $software;
    }

    /**
     * @return Software|null
     */
    public function getSoftware()
    {
        return $this->software;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
