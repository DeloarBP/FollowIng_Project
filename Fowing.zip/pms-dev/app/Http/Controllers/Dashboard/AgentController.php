<?php

namespace App\Http\Controllers\Dashboard;

use App\Events\AgentApplicationReceived;
use App\Events\AgentStatusChanged;
use App\Http\Requests\AgentApplicationRequest;
use App\Http\Requests\UpdateAgentRequest;
use App\Models\Agent;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AgentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->response['agents'] = Agent::with(['district', 'user'])->paginateSearchResult( config('agents.item_per_page', 30) );
        return view('dashboard.agents.index', $this->response);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.agents.create', $this->response);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\AgentApplicationRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AgentApplicationRequest $request)
    {
        $agent = Agent::create($request->toArray());
        event(new AgentApplicationReceived($agent));
        flash('Agent application received.')->success();
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function show(Agent $agent)
    {
        //TODO implement
        flash('This functionality not done yet')->info();
        return redirect()->back();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function edit(Agent $agent)
    {
        $this->response['agent'] = $agent;
        return view('dashboard.agents.edit', $this->response);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateAgentRequest  $request
     * @param  \App\Models\Agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateAgentRequest $request, Agent $agent)
    {
        $previous_status = $agent->status;

        $agent->fill($request->toArray());
        $agent->status = $request->status;
        $agent->save();

        if($request->status !=  $previous_status )
        {
            event(new AgentStatusChanged($agent));
        }

        flash('Agent information updated.')->success();

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function destroy(Agent $agent)
    {
        //TODO implement
        flash('This functionality not done yet')->info();
        return redirect()->back();
    }
}
