<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Requests\DepartmentStoreRequest;
use App\Http\Requests\DepartmentUpdateRequest;
use App\Models\Department;
use App\Http\Controllers\Controller;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->response['departments'] = Department::paginateSearchResult( config('departments.item_per_page', 30));
        return view('dashboard.departments.index', $this->response);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.departments.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\DepartmentStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DepartmentStoreRequest $request)
    {
        $department = Department::create($request->all());
        flash("Department {$department->name} successfully added.")->success();
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {
        $this->response['department'] = $department;
        return view('dashboard.departments.show', $this->response);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function edit(Department $department)
    {
        $this->response['department'] = $department;
        return view('dashboard.departments.edit', $this->response);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\DepartmentUpdateRequest  $request
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function update(DepartmentUpdateRequest $request, Department $department)
    {
        $department->fill($request->all())->save();
        flash("Department {$department->name} successfully updated.")->success();
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function destroy(Department $department)
    {
        flash("Destroy: {$department->name} this functionality not done yet.")->info();
        //TODO implement destroy
        return redirect()->back();
    }

    /**
     * Indications list of this department
     *
     * @param Department $department
     * @return \Illuminate\Http\Response
     */
    public function indications(Department $department)
    {
        $this->response['department'] = $department;
        $this->response['indications'] = $department->indications()->paginate(config('departments.indications.item_per_page'));
        return view('dashboard.departments.indications', $this->response);
    }

    /**
     * Software list of this department that already installed
     *
     * @param Department $department
     * @return \Illuminate\Http\Response
     */
    public function softwares(Department $department)
    {
        //TODO implement same as  self::indication()
        flash('This functionality not done yet')->info();
        return redirect()->back();
    }

}
