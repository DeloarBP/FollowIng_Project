<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Department;
use App\Http\Controllers\Controller;
use App\Models\Indication;
use DB;

class DepartmentIndicationController extends Controller
{

    /**
     * Get attachable indication of a department
     * @param \App\Models\Department $department
     * @return array indications
     */
    public function getAttachableIndications(Department $department)
    {
        $indications = Indication::search( request()->q )
            ->whereNotExists(function($query) use ($department) {

                      $query->select(DB::raw(1))
                          ->from('relation_department_indication')
                          ->whereRaw('relation_department_indication.indication_id = indications.id')
                          ->whereRaw("relation_department_indication.department_id = {$department->id}");

            })->paginate(20);

        $indications_array = [];
        foreach($indications as $indication)
        {
            $indications_array[] = [
              'title'           => $indication->title,
              'attachable_url'  => route('attach_indication', [$department->id, $indication->id]),
            ];
        }

        return $indications_array;
    }

    /**
     * Attache a indication with a department
     * for available at default installable
     *
     * @param Department $department
     * @param Indication $indication
     * @return \Illuminate\Http\RedirectResponse
     */
    public function attachIndication(Department $department, Indication $indication)
    {
       $department->indications()->attach($indication);
       $message = sprintf('Indication <strong>%s</strong>  successfully attached with department <strong>%s</strong>',$indication->title,$department->name);
       flash( $message )->success();
       return redirect()->back();
    }

    /**
     * Detach a indication form a department
     *
     * @param Department $department
     * @param Indication $indication
     * @return \Illuminate\Http\RedirectResponse
     */
    public function detachIndication(Department $department, Indication $indication)
    {
        $department->indications()->detach($indication);
        $message = sprintf('Indication <strong>%s</strong>  successfully detached form department <strong>%s</strong>',$indication->title,$department->name);
        flash( $message )->success();
        return redirect()->back();
    }

}
