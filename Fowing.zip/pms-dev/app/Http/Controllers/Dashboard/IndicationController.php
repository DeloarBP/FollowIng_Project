<?php

namespace App\Http\Controllers\Dashboard;

use App\Events\IndicationCreated;
use App\Http\Requests\IndicationUpdateRequest;
use App\Http\Requests\IndicationStoreRequest;
use App\Models\Indication;
use App\Http\Controllers\Controller;

class IndicationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->response['indications'] = Indication::paginateSearchResult( config('indications.item_per_page', 30) );;
        return view('dashboard.indications.index', $this->response);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.indications.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\IndicationStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(IndicationStoreRequest $request)
    {
        $indication = Indication::create($request->all());
        event(new IndicationCreated($indication));
        flash('Indication successfully created.')->success();
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Indication  $indication
     * @return \Illuminate\Http\Response
     */
    public function show(Indication $indication)
    {
        flash("Preview: {$indication->title} this functionality not done yet.")->info();
        //TODO implement show
        return redirect()->back();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Indication  $indication
     * @return \Illuminate\Http\Response
     */
    public function edit(Indication $indication)
    {
        $this->response['indication'] = $indication;
        return view('dashboard.indications.edit', $this->response);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\IndicationUpdateRequest  $request
     * @param  \App\Models\Indication  $indication
     * @return \Illuminate\Http\Response
     */
    public function update(IndicationUpdateRequest $request, Indication $indication)
    {
        $indication->fill($request->toArray())->save();
        flash('Indication successfully updated.')->success();
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Indication  $indication
     * @return \Illuminate\Http\Response
     */
    public function destroy(Indication $indication)
    {
        flash("Destroy: {$indication->title} this functionality not done yet.")->info();
        //TODO implement destroy
        return redirect()->back();
    }
}
