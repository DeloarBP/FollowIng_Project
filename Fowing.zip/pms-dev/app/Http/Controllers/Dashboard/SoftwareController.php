<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Requests\SoftwareInstallationRequest;
use App\Models\Agent;
use App\Models\Department;
use App\Models\Software;
use App\Models\SoftwareDepartment;
use App\Services\SoftwareInstallationService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SoftwareController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->response['softwares'] = Software::search()
            ->with(['agent', 'user', 'department', 'district', 'upazila'])
            ->paginate(30);
        return view('dashboard.softwares.index', $this->response);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->response['agents'] = Agent::orderBy('name', 'asc')->get();
        $this->response['departments'] = Department::orderBy('name', 'asc')->get();

        return view('dashboard.softwares.create', $this->response);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\SoftwareInstallationRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SoftwareInstallationRequest $request)
    {

        $software = new Software($request->toArray());

        (new SoftwareInstallationService($software))->install();

        flash("Software successfully installed. Software ID:" . $software->id )->success();

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {
        $this->response['department'] = $department;
        return view('dashboard.departments.show', $this->response);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SoftwareDepartment  $doctorCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(SoftwareDepartment $doctorCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SoftwareDepartment  $doctorCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SoftwareDepartment $doctorCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SoftwareDepartment  $doctorCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(SoftwareDepartment $doctorCategory)
    {
        //
    }

    /**
     * Indications list of this department
     *
     * @param Department $department
     * @return \Illuminate\Http\Response
     */
    public function indications(Department $department)
    {
        $this->response['department'] = $department;
        $this->response['indications'] = $department->indications()->distinct()
            ->orderBy('title', 'ASC')
            ->paginate(30);
        return view('dashboard.departments.indications', $this->response);
    }
}
