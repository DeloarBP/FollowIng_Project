<?php
/**
 * Created by PhpStorm.
 * User: shahadat
 * Date: 8/16/2017
 * Time: 12:48 AM
 */
namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Auth;

class WelcomeController extends Controller
{
    public function index()
    {
        $role = Auth::user()->roles()->first()->name;
        switch ($role)
        {
            case 'admin':
                return $this->adminIndex();

            case 'operator':
                return $this->operatorIndex();
        };
    }

    public function adminIndex()
    {
        return view('dashboard.welcome.admin', $this->response);
    }


    public function operatorIndex()
    {
        return view('dashboard.welcome.operator', $this->response);
    }
}