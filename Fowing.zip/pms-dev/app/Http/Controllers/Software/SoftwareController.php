<?php
/**
 * Created by PhpStorm.
 * User: shaha
 * Date: 9/15/2017
 * Time: 8:50 PM
 */

namespace App\Http\Controllers\Software;
use App\Http\Controllers\Controller;
use App\Models\Software;

class SoftwareController extends  Controller
{
    protected  $response = [];

    public function __construct(Software $software)
    {
        $this->response['software'] = $software;
    }
}