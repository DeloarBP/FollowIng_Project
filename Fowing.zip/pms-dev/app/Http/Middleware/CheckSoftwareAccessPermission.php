<?php

namespace App\Http\Middleware;

use App\Models\Software;
use Closure;
use Illuminate\Support\Facades\Auth;

class CheckSoftwareAccessPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ( !Auth::check() || $request->route('software')->authUserCan('visit') ) {
            return $next($request);
        }

        flash('Your are not authorized to visit that software.');
        return redirect()->back();
    }
}
