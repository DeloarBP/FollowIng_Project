<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Auth;

class AgentApplicationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::user() &&  ( $this->user_id == Auth::id() || Auth::user()->can('manage-agent') ) ;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id'   => 'required|exists:users,id',
            'name'      => 'required|max:100',
            'phone'     => 'required|max:30',
            'email'     => 'required|email|max:30',
            'division_id'=> 'required|exists:location_divisions,id',
            'district_id'=> 'required|exists:location_districts,id',
            'upazila_id' => 'required|exists:location_upazilas,id',
            'address'   => 'required|max:500',
        ];
    }
}
