<?php
/**
 * Created by PhpStorm.
 * User: shaha
 * Date: 9/3/2017
 * Time: 5:38 PM
 */

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class DepartmentUpdateRequest extends  FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        //TODO change permission name departments-management to manage-departments
        return Auth::user() && Auth::user()->can('department-management') ;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'                 => 'required',
        ];
    }
}