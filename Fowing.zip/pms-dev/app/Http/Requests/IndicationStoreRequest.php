<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Auth;

class IndicationStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        //TODO change permission name indications-management to manage-indications
        return Auth::user() && Auth::user()->can('indications-management') ;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'                 => 'required',
            'default_duration'      => 'required',
            'duration_time_frame'   => 'required', //TODO check exists in config. indications.time_frame
        ];
    }
}
