<?php
/**
 * Created by PhpStorm.
 * User: shaha
 * Date: 9/3/2017
 * Time: 5:38 PM
 */

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class IndicationUpdateRequest extends  FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        //TODO change permission name indications-management to manage-indications
        return Auth::user() && Auth::user()->can('indications-management') ;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'                 => 'required',
            'default_duration'      => 'required',
            'duration_time_frame'   => 'required', //TODO check exists in config. indications.time_frame
        ];
    }
}