<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Auth;

class SoftwareInstallationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::user() &&  ( $this->user_id == Auth::id() || Auth::user()->can('manage-software') );
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id'        => 'required|exists:users,id',
            'title'          => 'required|max:100',
            'agent_id'       => 'required|exists:agents,id',
            'department_id'  => 'required|exists:departments,id',
        ];
    }
}
