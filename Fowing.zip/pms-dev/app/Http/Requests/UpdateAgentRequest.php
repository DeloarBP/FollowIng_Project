<?php

namespace App\Http\Requests;

use App\Models\Agent;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class UpdateAgentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if(!Auth::user())
        {
            return false;
        }
        $agent =  Agent::findOrFail($this->segment(3));
        $is_self = $agent->user_id == Auth::id();

        return  Auth::user()->can('manage-agent') || $is_self ;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id'   => 'required|exists:users,id',
            'name'      => 'required|max:100',
            'phone'     => 'required|max:30',
            'email'     => 'required|email|max:30',
            'address'   => 'required|max:500',
        ];
    }
}
