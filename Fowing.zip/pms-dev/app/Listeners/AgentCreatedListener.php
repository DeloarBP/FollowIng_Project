<?php

namespace App\Listeners;

use App\Events\AgentApplicationReceived;
use App\Notifications\WelcomeAgent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class AgentCreatedListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  Event  $event
     * @return void
     */
    public function handle(AgentApplicationReceived $event)
    {
        $event->getAgent()->user->notify(new WelcomeAgent());
        //TODO Notify all administrator a new agent created
    }
}
