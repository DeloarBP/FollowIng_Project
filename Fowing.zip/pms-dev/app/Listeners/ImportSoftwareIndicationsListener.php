<?php

namespace App\Listeners;

use App\Events\SoftwareInstalled;
use App\Mail\WelcomeToSoftware;
use App\Models\SoftwareIndication;
use Illuminate\Support\Facades\Mail;
class ImportSoftwareIndicationsListener
{

    /**
     * Handle the event.
     *
     * @param  SoftwareInstalled  $event
     * @return void
     */
    public function handle(SoftwareInstalled $event)
    {
        $indications = [];

        foreach($event->getSoftware()->department->indications as $indication)
        {
            $indications[] = new SoftwareIndication($indication->toArray());
        }

        $event->getSoftware()->indications()->saveMany($indications);

        return true;
    }
}
