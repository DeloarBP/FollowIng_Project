<?php

namespace App\Listeners;

use App\Events\SoftwareInstalled;
use App\Mail\WelcomeToSoftware;
use Illuminate\Support\Facades\Mail;
class SoftwareInstalledListener
{


    /**
     * Handle the event.
     *
     * @param  SoftwareInstalled  $event
     * @return void
     */
    public function handle(SoftwareInstalled $event)
    {
        /**
         * Sending mail and notification to doctor
         */
        $doctor_account = $event->getSoftware()->user;
        $welcome_mail = new WelcomeToSoftware($event->getSoftware());
        Mail::to($doctor_account)->send($welcome_mail);

        //TODO notification


        /**
         * Sending mail and notification to agent
         */
        //TODO implementation

        /**
         * Sending mail and notification to all admin
         */
        //TODO implementation

        return true;
    }
}
