<?php

namespace App\Mail;

use App\Models\Software;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class WelcomeToSoftware extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * @var Software|null
     */
    protected $software = null;

    /**
     * WelcomeToSoftware constructor.
     * @param Software $software
     */
    public function __construct(Software $software)
    {
        $this->software = $software;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from(config('company.emails.welcome_to_software') )
            ->markdown('emails.softwares.welcome');
    }
}
