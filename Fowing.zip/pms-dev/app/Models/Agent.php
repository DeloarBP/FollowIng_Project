<?php

namespace App\Models;

use App\Models\Location\District;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Kyslik\ColumnSortable\Sortable;


class Agent extends Model
{
    use SoftDeletes;
    use Searchable;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    /**
     * The attributes that should be mass assignable
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'address',
        'user_id',
        'division_id',
        'district_id',
        'upazila_id',
    ];

    protected $sortable = [
        'id',
        'name',
        'email',
        'phone',
    ];

    protected $searchable = [
        'id',
        'name'  => '%like%',
        'email' => '%like%',
        'phone' => '%like%',
    ];





    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function softwares()
    {
        return $this->hasMany(Software::class);
    }

    public function district()
    {
        return $this->belongsTo(District::class);
    }



    /**
     * Set valid status attribute
     *
     * @param null $status
     */
    public function setStatusAttribute($status = null)
    {
        $available_status = array_keys(config('agents.status'));

        $this->attributes['status'] =  in_array($status, $available_status ) ?
            $status : config('agents.default_status');
    }

}
