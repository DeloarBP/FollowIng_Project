<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Department extends Model
{
    use Searchable;
    use SoftDeletes;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['created_at', 'updated_at', 'deleted_at'];

    protected $sortable = [
        'id',
        'name',
    ];

    protected $searchable = [
        'id',
        'name'  => '%like%',
    ];

    protected $fillable = [
        'name'
    ];

    /**
     * Get installed software of this department
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function softwares()
    {
        return $this->hasMany(Software::class);
    }



    /**
     * Get indications of this departments
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function indications()
    {
        $indicationsQuery = $this->belongsToMany(Indication::class, 'relation_department_indication');

        if(request()->sort)
        {
            $type = strcasecmp(request()->order, 'DESC') ? 'ASC' : 'DESC';
            $indicationsQuery->orderBy(request()->sort, $type);
        }

        if(request()->search)
        {
            $indicationsQuery->where(function($indicationsQuery){
                foreach( (new Indication)->getSearchableFields() as $key => $field)
                {
                    if(is_numeric($key))
                        $indicationsQuery->orWhere($field, request()->search);
                    else
                        $indicationsQuery->orWhere($key, 'like', str_replace('like', request()->search, $field));
                }
            });
        }

        return $indicationsQuery;
    }


    /**
     * Get number of software installed
     *
     * @return integer
     */
    public function getSoftwareInstalledAttribute()
    {
        //TODO calculate and return real data
        return rand(10,25);
    }


    /**
     * Get number of software installed
     *
     * @return integer
     */
    public function count($key = null)
    {
        switch($key)
        {
            case 'indications':
                return $this->indications()->count();
            case 'softwares':
                return $this->softwares()->count();
        }

        return 0;
    }


}
