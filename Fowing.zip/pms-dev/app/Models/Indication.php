<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Indication extends Model
{
    use Searchable;
    use SoftDeletes;

    protected $sortable = [
        'id',
        'title',
        'default_duration',
        'default_time_frame',
    ];

    protected $searchable = [
        'id',
        'title'  => '%like%',
    ];

    /**
     * @var array
     */
    protected $fillable =  [
        'title',
        'default_duration',
        'default_time_frame',
    ];

    /**
     * relation with Installable department
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function departments()
    {
        return $this->belongsToMany(Department::class, 'relation_department_indication');
    }

    /**
     * Get number of installable department
     *
     * @return int
     */
    public function getNumOfDepartmentAttribute()
    {
        //TODO have to return real data
        return rand(0, 50);
    }

    /**
     * Get query builder of search result
     *
     * @param string $key
     * @return $this
     */
    public static function  search($key = '')
    {
        //TODO implement search functionality using trait
        return static::where('id', '<>', -1)
            ->where('title', 'like', "%{$key}%");
    }
}
