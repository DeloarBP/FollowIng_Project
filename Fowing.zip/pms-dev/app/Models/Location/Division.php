<?php

namespace App\Models\Location;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Division extends Model
{
    use SoftDeletes;
	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['created_at','updated_at','deleted_at'];

    /**
     * The attributes define the db table name
     *
     * @var string
     */
    protected $table = 'location_divisions';

    public function districts()
    {
    	return $this->hasMany(District::class);
    }
        
    public function upazilas()
    {
    	return $this->hasMany(Upazila::class);
    }
}
