<?php

namespace App\Models;

use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission
{
    /**
     * Mass assignable property list
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'name',
        'display_name',
        'group',
        'type',
        'description',
    ];
}
