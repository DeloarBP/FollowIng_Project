<?php
namespace  App\Models;


use Kyslik\ColumnSortable\Sortable;

trait Searchable
{

    use Sortable;

    /**
     * @param $query
     * @param null $search
     * @return mixed
     */
    public function scopeSearch($query, $search = null)
    {
        if(is_null($search))
            return $query;

        foreach($this->getSearchableFields() as $key => $field)
        {
            if(is_numeric($key))
                $query->orWhere($field, $search);
            else
                $query->orWhere($key, 'like', str_replace("like", $search, $field));
        }

        return $query;
    }


    /**
     * Get search result
     *
     * @return mixed
     */
    public function scopePaginateSearchResult($query, $limit = null)
    {
        return $query->search(request()->search)
            ->sortable()
            ->paginate($limit);
    }

    /**
     * @return array
     */
    public function getSearchableFields()
    {
        return isset($this->searchable) ? $this->searchable : [];
    }
}