<?php

namespace App\Models;

use App\Models\Location\District;
use App\Models\Location\Division;
use App\Models\Location\Upazila;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class Software extends Model
{
    use SoftDeletes;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'installed_at',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    /**
     * The attributes define the mass assignable property
     * @var array
     */
    protected $fillable = [
        'title',
        'user_id',
        'agent_id',
        'department_id',
        'division_id',
        'district_id',
        'upazila_id',
    ];

    public static function  search($key = '')
    {
        return static::where('id', '<>', -1);

        //TODO implement search functionality using trait
        $search_config = static::getSearchConfiguration();
        foreach($search_config['order_by'] as $field_name => $order_type )
        {
            $query->orderBy($field_name, $order_type);
        }
        $query->limit($search_config['limit']);
        $query->offset($search_config['offset']);
    }


    public function agent()
    {
        return $this->belongsTo(Agent::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function district()
    {
        return $this->belongsTo(District::class);
    }

    public function upazila()
    {
        return $this->belongsTo(Upazila::class);
    }

    public function division()
    {
        return $this->belongsTo(Division::class);
    }

    public function indications()
    {
        return $this->hasMany(SoftwareIndication::class, 'software_id');
    }


    /**
     * Check permission
     *
     * @param $permission
     * @return bool
     */
    public function authUserCan($permission)
    {
        switch ($permission)
        {
            case 'visit':
                return  Auth::check() && $this->user_id ==  Auth::id();
                break;
        }
    }
}
