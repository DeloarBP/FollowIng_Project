<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SoftwareIndication extends Model
{
    /**
     * This property define which property is mass assignable
     *
     * @var array
     */
    protected $fillable = [
        'title',
        'default_duration',
        'duration_time_frame',
    ];


    public function software()
    {
        return $this->belongsTo(Software::class);
    }
}