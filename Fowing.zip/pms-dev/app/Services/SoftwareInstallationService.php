<?php
/**
 * Created by PhpStorm.
 * User: Shahadat
 * Date: 8/20/2017
 * Time: 12:22 PM
 */

namespace App\Services;

use App\Events\SoftwareInstalled;
use App\Models\Software;
use App\Models\SoftwareIndication;
use Carbon\Carbon;

class SoftwareInstallationService
{
    protected  $software = null;

    public function __construct(Software $software)
    {
        $this->software = $software;
    }

    /**
     *
     *
     * 
     * Install the software
     *
     * -Installation step
     *  --mark As Installed
     *  --import Indications
     *  --TODO many things
     *  --fire event
     */
    public function install()
    {
        $this->software->status       = config('softwares.installed_status');
        $this->software->installed_at = Carbon::now();
        //TODO collect data from form
        $this->software->district_id = 1;
        $this->software->upazila_id = 1;
        $this->software->division_id = 1;
        $this->software->save();

        event(new SoftwareInstalled($this->software));
    }



}