<?php

/**
 * Get backable url for a route
 * 
 */
function backAbleUrl($route = '')
{
	$query	= "rb=" . urlencode(request()->fullUrl());
	$url 	= url( $route );
	/**
	 * 3rd Prty code
	 * @url http://stackoverflow.com/questions/5215684/append-query-string-to-any-form-of-url
	 */
	$parsedUrl = parse_url( $url );
   	if ($parsedUrl['path'] == null) {
      	$url .= '/';
   	}
   	$separator = ( @$parsedUrl['query'] == NULL) ? '?' : '&';
   	$url .= $separator . $query;
   	/**End 3rd party code */
	return  $url;
}


/**
 * 
 * Redirect to previous page 
 * if available otherwise given url
 * 
 * 
 */
function backAbleRedirect($url = '')
{
	$redirect_url =  request()->rb ?:  $url ;

	return redirect( $redirect_url ); 
}


/**
 * Generate sortable link
 */
function shortableUrl($order_by = 'id', $ordery_type = 'ASC', $appends = ['q', 'page'])
{
    $query = array();

    foreach ($appends as $temp) {
        $query[$temp] = request()->$temp;
    }
    $query['order_by']   = $order_by;
    $query['order_type'] = $ordery_type;

    return request()->url() . '?' . http_build_query($query);
}

/**
 *  Generate sortable anchore
 */
function shortableLink($lebel, $order_by = 'id', $order_type = 'ASC', $appends = ['q', 'page'], $attributes = [])
{
    $attributes_str = "";

    if (request()->order_by == $order_by) {
        $order_type = request()->order_type == 'ASC' ? 'DESC' : 'ASC';
    }

    $attributes['href'] = shortableUrl($order_by, $order_type, $appends);

    foreach ($attributes as $key => $value) {
        $attributes_str .= " $key = \"$value\" ";
    }

    return sprintf('<a %s>%s <i class="fa fa-sort" aria-hidden="true"></i></a>', $attributes_str, $lebel);
}



/**
 * Convert collectin to list
 *
 * @param  Collection $collection
 * @param  String|Array $key     key field of collection
 * @param String|Array $value    value field of collection
 *
 * @return array $list
 */
function collection_to_list($collection, $key, $value)
{
    $temp = $collection->toArray();

    /** @var keys [description] */
    $keys = array();
    if (is_array($key)) {
        $map_column[] = function () {
            $values = func_get_args();

            $temp = '';
            foreach ($values as $value) {
                $temp .= " " . $value;
            }
            return $temp;
        };

        foreach ($key as $k) {
            $map_column[] = array_column($temp, $k);
        }
        $keys = call_user_func_array('array_map', $map_column);
    } else {
        $keys = array_column($temp, $key);
    }

    /** @var values [description] */
    $values = array();
    if (is_array($value)) {
        $map_column[] = function () {
            $values = func_get_args();

            $temp = '';
            foreach ($values as $value) {
                $temp .= " " . $value;
            }
            return $temp;
        };

        foreach ($value as $k) {
            $map_column[] = array_column($temp, $k);
        }
        $values = call_user_func_array('array_map', $map_column);
    } else {
        $values = array_column($temp, $value);
    }

    return array_combine($keys, $values);
}

function collection2list($collection, $key, $value)
{
    return collection_to_list($collection, $key, $value);
}