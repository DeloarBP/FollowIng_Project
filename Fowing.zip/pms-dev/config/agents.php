
<?php

return [
    'item_per_page'  => 3,
    'default_status' => 'approved',
    'status' => [
        'applied'   => [
            'label' => 'Applied',
            'class' => 'label label-info',
        ],
        'approved'  => [
            'label' => 'Approved',
            'class' => 'label label-success',
        ],
        'denied'  => [
            'label' => 'Denied',
            'class' => 'label label-danger',
        ],
        'suspended'  => [
            'label' => 'Suspended',
            'class' => 'label label-warning',
        ],
    ],
];
