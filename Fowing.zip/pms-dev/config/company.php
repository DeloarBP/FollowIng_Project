<?php
return [

    'emails' => [
        'welcome_to_software' => 'shahadat@tamjid.com'
    ],

];