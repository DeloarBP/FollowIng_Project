
<?php

return [
    'item_per_page'  => 3,

    'indications'     => [
        'item_per_page'   => 3,
    ],

    //Used on index page of department
    'installable_count_mapping' => [
        'indications'           => [
            'label' => 'Installable indications',
            'title' => 'Automatically imported when new software installed.',
            'route' => 'department_indications',
        ],
    ]
];
