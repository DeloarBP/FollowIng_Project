<?php


return [
    'item_per_page' => 3,
    'default_duration_time_frame' => 'day',
    /**
     * This time option comes with many option like
     * Chief complain
     */
    //TODO remove and replace time_frame  with time_frame_list or time_frame_arr
    'time_frame'  =>  [
        'hour'      => 'Hours',
        'day'       => 'Days',
        'month'     => 'Months',
        'year'      => 'Years',
    ],

];