
<?php

return [
    'default_status' => 'installing',
    'installed_status' => 'running',
    'status' => [
        'installing'   => [
            'label' => 'Installing',
            'class' => 'label label-info',
        ],
        'running'   => [
            'label' => 'Running',
            'class' => 'label label-success',
        ],
    ],
];
