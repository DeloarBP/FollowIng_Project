<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDepartmentsIndicationsRelationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $this->down();
        Schema::create('relation_department_indication', function (Blueprint $table) {
            $table->integer('department_id')->unsigned();
            $table->integer('indication_id')->unsigned();
        });

        //TODO create primary key foreign key constraint
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('relation_department_indication');
    }
}
