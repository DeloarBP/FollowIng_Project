<?php

use Illuminate\Database\Seeder;

class AgentsSeeder extends Seeder{

    protected static $agents = [
        [
            'name'      => 'Kalponic Software Company',
            'user_id'   => 4,
        ],
        [
            'name'      => 'Another Software Company',
            'user_id'   => 2,
        ],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach(self::$agents as $agent)
        {
            DB::table('agents')->insert([
                'name' => $agent['name'],
                'user_id' =>  $agent['user_id']
            ]);
        }
    }
}