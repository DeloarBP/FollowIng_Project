<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UsersTableSeeder::class);
        $this->call(AgentsSeeder::class);
        $this->call(SoftwaresSeeder::class);
        $this->call(UserPermissionSeeder::class);

        DB::transaction(function () {
            DB::insert( file_get_contents( dirname( __FILE__ ) . '/../sqls/departments.sql' ) );
            DB::insert( file_get_contents( dirname( __FILE__ ) . '/../sqls/indications.sql' ) );
            DB::insert( file_get_contents( dirname( __FILE__ ) . '/../sqls/relation_department_indication.sql' ) );
            DB::insert( file_get_contents( dirname( __FILE__ ) . '/../sqls/location_divisions.sql' ) );
            DB::insert( file_get_contents( dirname( __FILE__ ) . '/../sqls/location_districts.sql' ) );
            DB::insert( file_get_contents( dirname( __FILE__ ) . '/../sqls/location_upazilas.sql' ) );
        });
    }

}
