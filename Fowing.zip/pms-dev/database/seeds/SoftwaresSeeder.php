<?php

use Illuminate\Database\Seeder;

class SoftwaresSeeder extends Seeder{

    protected static $softwares = [
        [
            'id'            => 1,
            'title'         => 'Medico Pharma',
            'district_id'   => 1,
            'department_id' => 1,
            'user_id'       => 5,
            'agent_id'      => 1,
            'division_id'   => 1,
            'upazila_id'    => 1,
        ],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach(self::$softwares as $software)
        {
            DB::table('softwares')->insert([
                'id'            => $software['id'],
                'title'         => $software['title'],
                'district_id'   => $software['district_id'],
                'upazila_id'    => $software['upazila_id'],
                'division_id'   => $software['division_id'],
                'department_id' => $software['department_id'],
                'user_id'       => $software['user_id'],
                'agent_id'      => $software['agent_id'],
            ]);
        }
    }
}