<?php

use App\Models\Permission;
use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\User;
/**
 * Created by PhpStorm.
 * User: shahadat
 * Date: 8/15/2017
 * Time: 11:26 PM
 */

class UserPermissionSeeder extends  Seeder
{
    public static $roleList = [
        [
            'id'            => 1,
            'name'          => 'admin',
            'display_name'  => 'Administrator',
            'description'   => 'Can perform any action and visit dashboard.',
            'user_ids'      => [1,2],
        ],
        [
            'id'            => 2,
            'name'          => 'agent',
            'display_name'  => 'Agent',
            'description'   => 'Can create software. And edit their own software.',
            'user_ids'      => [4],
        ],
    ];

    public static $permissionList = [
        [
            'id'            => 1,
            'name'          => 'create-agent',
            'display_name'  => 'Create Agent',
            'group'         => 'Agent',
            'type'          => 'create',
            'description'   => 'Can create software. And edit their own software.',
            'role_ids'      => [1],
        ],
        [
            'id'            => 2,
            'name'          => 'access-dashboard',
            'display_name'  => 'Access dashboard',
            'group'         => 'Dashboard',
            'type'          => 'show',
            'description'   => 'Without this permission no user can enter dashboard panel.',
            'role_ids'      => [1]
        ],
        [
            'id'            => 3,
            'name'          => 'manage-agent',
            'display_name'  => 'Perform Anything of agent',
            'group'         => 'Agents',
            'type'          => 'manage',
            'description'   => 'Create read delete agents',
            'role_ids'      => [1]
        ],
        [
            'id'            => 4,
            'name'          => 'indications-management',
            'display_name'  => 'Perform Anything of indication',
            'group'         => 'Indications',
            'type'          => 'Management',
            'description'   => 'Create read delete agents',
            'role_ids'      => [1]
        ],
        [
            'id'            => 5,
            'name'          => 'department-management',
            'display_name'  => 'Perform Anything of department',
            'group'         => 'Department',
            'type'          => 'Management',
            'description'   => 'Create read delete agents',
            'role_ids'      => [1]
        ],
        [
            'id'            => 6,
            'name'          => 'manage-software',
            'display_name'  => 'Perform Anything of department',
            'group'         => 'Software',
            'type'          => 'Management',
            'description'   => 'Create read delete agents',
            'role_ids'      => [1]
        ],
    ];

    /**
     * Run user permission
     */
    public function run()
    {

        /**
         * Create all role and attach to user
         */
        foreach(static::$roleList as $role)
        {
           $roleObj =  Role::create([
               'id'             => $role['id'],
               'name'           => $role['name'],
               'display_name'   => $role['display_name'],
               'description'    => $role['description'],
           ]);

           foreach($role['user_ids'] as  $user_id)
           {
               $user = User::find($user_id);
               $user->attachRole($roleObj);
           }
        }

        /**
         * Create all role and attach to role
         */
        foreach(static::$permissionList as $permission)
        {
            $permissionObj =  Permission::create([
                'id'             => $permission['id'],
                'name'           => $permission['name'],
                'display_name'   => $permission['display_name'],
                'description'    => $permission['description'],
                'group'          => $permission['group'],
                'type'           => $permission['type'],
            ]);

            foreach($permission['role_ids'] as  $role_id)
            {
                $role = Role::find($role_id);
                $role->attachPermission($permissionObj);
            }
        }
    }
}