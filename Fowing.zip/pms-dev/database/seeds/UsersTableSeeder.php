<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder{

    protected static $users = [
        [
            'id'     => 1,
            'name'   => 'Shahadat Hossain',
            'email'  => 'shahadat.zcpe@gmail.com',
            'password' => 'secret'
        ],
        [
            'id'     => 2,
            'name'   => 'Admin',
            'email'  => 'admin@pms.dev',
            'password' => 'secret'
        ],
        [
            'id'     => 3,
            'name'   => 'Call Center',
            'email'  => 'call@pms.dev',
            'password' => 'secret'
        ],
        [
            'id'     => 4,
            'name'   => 'Agent',
            'email'  => 'agent@pms.dev',
            'password' => 'secret'
        ],
        [
            'id'     => 5,
            'name'   => 'Doctor',
            'email'  => 'doctor@pms.dev',
            'password' => 'secret'
        ],
        [
            'id'     => 6,
            'name'   => 'Compounder',
            'email'  => 'compounder@pms.dev',
            'password' => 'secret'
        ],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach(self::$users as $user)
        {
            DB::table('users')->insert([
                'id'        => $user['id'],
                'name'      => $user['name'],
                'email'     =>  $user['email'],
                'password'  => bcrypt( $user['password'] ),
            ]);
        }
    }
}