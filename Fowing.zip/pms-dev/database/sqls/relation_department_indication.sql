
INSERT INTO `relation_department_indication` (`department_id`, `indication_id`) VALUES
	(2, 89),
	(2, 1430),
	(2, 105),
	(2, 144),
	(2, 938);