
/**
 Ajax Modal Functionality
**/
$(document).ready(function() {
	$(document).on('click','[data-toggle="ajax-modal"]',function(e) {
		e.preventDefault();
		var url = $(this).attr('href');
		
		$.get(url, function(data) {
			$modal = $('<div class="ajax-modal">' + data + '</div>');
			$('body').append($modal);
			$modal.show();
		});
	});

	$(document).on('click','.ajax-modal .ajax-modal-close',function() {
		$(this).parents('.ajax-modal').remove();
	});

	/**Hide flash message jeffry's package*/
	$('div.alert').not('.alert-important').delay(3000).fadeOut(350);







	$(document).on('click', '#menu-item .builder .expand',function(event){
		event.preventDefault();
		$(this).closest('.dd-item').toggleClass('expanded');

	});


	
});

